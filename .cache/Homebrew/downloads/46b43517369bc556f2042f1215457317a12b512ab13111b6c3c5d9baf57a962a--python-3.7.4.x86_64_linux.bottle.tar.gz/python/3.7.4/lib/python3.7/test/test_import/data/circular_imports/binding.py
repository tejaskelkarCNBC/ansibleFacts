import test.test_import.data.circular_imports.binding2 as binding2
